# recommendations_logic.py

def get_book_recommendations(user_answers):
    """
    Get book recommendations based on user answers.

    Parameters:
    - user_answers: A list of user answers.

    Returns:
    - recommendations: A list of book recommendations.
    """
    # Dictionary mapping user answer combinations to book recommendations
    recommendations_dict = {
        ('Long', 'Horror', 'Yes'): ["The Dark Tower Series by Stephen King", "The Darkest Tower Series by Alexandra Bracken", "Asylum Series by Madeleine Roux"],
        ('Long', 'Horror', 'No'): ["Terrifying Tales Series by Mary Downing Hahn", "Five Nights at Freddy’s series by Scott Cawthon", "Goosebumps Series by R. L. Stine"],
        ('Long', 'Romance', 'Yes'): ["It Ends With Us by Colleen Hoover", "Unmasked Heart by Vanessa Riley", "Silver Silence by Nalini Singh"],
        ('Long', 'Romance', 'No'): ["Check & Mate by Ali Hazel Wood", "House of Marionne by J. Elle", "Instructions for Dancing by Nicola Yoon"],
        ('Long', 'Comedy', 'Yes'): ["Is Everyone Hanging Out Without Me? By Mindy Kaling", "Me Talk Pretty One Day by David Sedaris", "The Ultimate Hitchhiker’s Guide to the Galaxy by Douglas Adams"],
        ('Long', 'Comedy', 'No'): ["Me and Earl and the Dying Girl by Jesse Andrews", "Dan Versus Nature by Don Calame", "Ungifted by Gordon Korman"],
        ('Long', 'Adventure/Fantasy', 'Yes'): ["Into the Wild by Jon Krakauer", "Life of Pi by Yann Martel", "King Solomon’s Mines by H. Rider Haggard"],
        ('Long', 'Adventure/Fantasy', 'No'): ["The Extinction Trails by S M Wilson", "The Boy Who Hit Play by Chloe Daykin", "Shadow of the Fox by Julie Kagawa"],
        ('Long', 'Non-fiction', 'Yes'): ["A Distant Mirror: The Calamitous 14th Century by Barbara W. Tuchman", "John Adams by David McCullough", "Nicholas and Alexandra by Robert K. Massie"],
        ('Long', 'Non-fiction', 'No'): ["The Faraway Brothers by Lauren Markham", "Flowers in the Gutter by K.R. Gaddy", "Yes She Can by Molly Dillion"],
        ('Short', 'Horror', 'Yes'): ["Small Horrors: A Collection of Fifty Creepy Stories by Darcy Coates", "The Inmate by Freida McFadden", "Don’t Let Her Stay by Nicola Sanders"],
        ('Short', 'Horror', 'No'): ["Carmilla by Sheridan Le Fanu", "Dracula by Bram Stoker", "Coraline By Neil Gaiman"],
        ('Short', 'Romance', 'Yes'): ["As If I Wouldn’t Fall by Jessa Kane", "The Surgeon by Nichole Rose", "Grumpy Jake by Melissa Blue"],
        ('Short', 'Romance', 'No'): ["The All the Boys I’ve Loved Before by Jenny Han", "Eleanor & Park by Rainbow Rowell", "The Fault in Our Stars by John Green"],
        ('Short', 'Comedy', 'Yes'): ["Good Omens by Neil Gaiman and Terry Pratchett", "Bossypants by Tina Fey", "Yes Please by Amy Poehler"],
        ('Short', 'Comedy', 'No'): ["Diary of a Wimpy Kid by Jeff Kinney", "Big Nate by Lincoln Pierce", "The 13-Story Treehouse by Andy Griffiths and Terry Denton"],
        ('Short', 'Adventure/Fantasy', 'Yes'): ["The Hobbit by J.R.R. Tolkien", "The Ocean at the End of the Lane by Neil Gaiman", "Stardust by Paulo Coelho"],
        ('Short', 'Adventure/Fantasy', 'No'): ["The Giver by Lois Lowry", "The Wee Free Men by Terry Pratchett", "The Graveyard Book by Neil Gaiman"],
        ('Short', 'Non-fiction', 'Yes'): ["The Four Agreements by Don Miguel Ruiz", "Educated by Tara Westover", "The Immortal Life of Henrietta Lacks by Rebecca Skloot"],
        ('Short', 'Non-fiction', 'No'): ["The Diary of a Young Girl by Anne Frank", "The Boy Who Harnessed the Wind by William Kamkwamba and Bryan Mealer", "Bomb: The Race to Build-And Steal-the World’s Most Dangerous Weapon by Steve Sheinkin"],
    }

    # Convert user_answers list to a tuple for dictionary lookup
    user_tuple = tuple(user_answers)

    # Retrieve recommendations based on user's answers
    recommendations = recommendations_dict.get(user_tuple, [])

    return recommendations
