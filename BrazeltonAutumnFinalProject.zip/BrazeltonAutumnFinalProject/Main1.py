import tkinter as tk
from welcome import WelcomeWindow
from questions import QuestionsWindow

class BookRecommendationsApp:
    def __init__(self):
        """
        Initialize the BookRecommendationsApp.

        This method creates the main Tkinter window and sets up the WelcomeWindow.

        Parameters:
        - None
        """
        self.root = tk.Tk()
        self.root.title("Book Recommendation App")
        self.welcome_window = WelcomeWindow(self.root, self.show_question_window)

    def show_question_window(self):
        """
        Show the QuestionsWindow.

        This method is called when the user clicks the "Start" button on the WelcomeWindow.
        It hides the main window and creates/display the QuestionsWindow.

        Parameters:
        - None
        """
        self.root.withdraw()  # Hide the main window temporarily
        questions_data = [
            {
                "question": "1.Do you like long or short books?",
                "answers": ["Long", "Short"]
            },
            {
                "question": "2.Which genre do you like best?",
                "answers": ["Horror", "Romance", "Comedy", "Adventure/Fantasy", "Non-fiction"]
            },
            {
                "question": "3.Are you 18 years or older? Be honest!",
                "answers": ["Yes", "No"]
            }
        ]

        # Create and display the QuestionsWindow
        self.questions_window = QuestionsWindow(self.root, questions_data, self.on_submit)

    def on_submit(self, user_answers):
        """
        Handle user answers.

        This method is a placeholder for handling user answers. Replace it with the desired logic.

        Parameters:
        - user_answers: A list of user's answers to quiz questions.

        Returns:
        - None
        """
        print("User answers:", user_answers)
        print("Show recommendations window")

    def run(self):
        """
        Run the Tkinter main loop.

        This method re-shows the main window and starts the Tkinter main loop.

        Parameters:
        - None
        """
        self.root.deiconify()  # Re-show the main window
        self.root.mainloop()

if __name__ == "__main__":
    app = BookRecommendationsApp()
    app.run()
