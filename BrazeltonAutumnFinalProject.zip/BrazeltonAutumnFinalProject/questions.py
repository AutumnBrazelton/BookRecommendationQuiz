import tkinter as tk
from tkinter import messagebox
from welcome import WelcomeWindow
from book_recommendations import get_book_recommendations

class QuestionsWindow(tk.Toplevel):
    def __init__(self, master, questions_data, on_submit):
        """
        Initialize the QuestionsWindow.

        This method sets up the QuestionsWindow, including handling user answers and displaying recommendations.

        Parameters:
        - master: The master Tkinter window.
        - questions_data: A list of dictionaries containing questions and answers.
        - on_submit: The function to call when the user submits answers.

        Returns:
        - None
        """
        super().__init__(master)
        self.title("Questions")
        self.geometry("400x200")  # Set the initial size of the window

        # Set the background color to red
        self.configure(bg="red")

        self.questions_data = questions_data
        self.on_submit = on_submit

        self.current_question_index = 0
        self.user_answers = []
        self.answer_vars = []

        self.label_question = tk.Label(self, text=questions_data[0]["question"], bg="red", fg="black")
        self.label_question.pack()

        self.answer_var = tk.StringVar()

        for answer in questions_data[0]["answers"]:
            answer_radio = tk.Radiobutton(self, text=answer, variable=self.answer_var, value=answer, bg="red", fg="black", command=self.on_answer_selected)
            answer_radio.pack()

        self.submit_button = tk.Button(self, text="Next", command=self.submit_answer, bg="white", fg="black")
        self.submit_button.pack()
        self.submit_button["state"] = "disabled"  # Disable the "Next" button initially

    def on_answer_selected(self):
        # Enable the "Next" button when an answer is selected
        self.submit_button["state"] = "normal"

    def submit_answer(self):
        """
        Submit the user's answer to the current question.

        This method is called when the user clicks the "Next" button. It validates the answer, updates the
        question if there are more questions, and displays recommendations if it's the last question.

        Returns:
        - None
        """
        user_answer = self.answer_var.get()

        if not user_answer:
            # Display an error message if the user tries to move on without answering
            messagebox.showerror("Error", "Please answer before moving on.")
        else:
            self.user_answers.append(user_answer)
            self.current_question_index += 1

            if self.current_question_index < len(self.questions_data):
                # If there are more questions, update the question
                self.update_question()
            else:
                # If it's the last question, show book recommendations
                self.show_recommendations()

    def update_question(self):
        """
        Update the displayed question and answers.

        This method clears the previous radio buttons, displays the new question and answers, and enables
        the "Next" button.

        Returns:
        - None
        """
        current_question = self.questions_data[self.current_question_index]
        self.label_question.config(text=current_question["question"])

        # Clear previous radio buttons
        for widget in self.winfo_children():
            if isinstance(widget, tk.Radiobutton) or isinstance(widget, tk.Button):
                widget.destroy()

        # Display new answers
        self.answer_var.set(None)
        for answer in current_question["answers"]:
            answer_radio = tk.Radiobutton(self, text=answer, variable=self.answer_var, value=answer, bg="red", fg="black", command=self.on_answer_selected)
            answer_radio.pack()

        # Display "Next" button
        self.submit_button = tk.Button(self, text="Next", command=self.submit_answer, bg="white", fg="black")
        self.submit_button.pack()
        self.submit_button["state"] = "disabled"  # Disable the "Next" button initially

    def show_recommendations(self):
        """
        Display book recommendations based on user answers.

        This method creates a new window for displaying recommendations, including book titles and an image.

        Returns:
        - None
        """
        recommendations = get_book_recommendations(self.user_answers)

        # Create a new window for displaying recommendations
        recommendations_window = tk.Toplevel(self)
        recommendations_window.title("Book Recommendations")

        # Display recommendations in the new window
        label_recommendations = tk.Label(recommendations_window, text="Based on your answers, you might enjoy these books:", bg="white", fg="green")
        label_recommendations.pack()

        for recommendation in recommendations:
            label_book = tk.Label(recommendations_window, text=recommendation, bg="white", fg="red")
            label_book.pack()

        # Load and display the GIF image
        image_path = "C:/Users/autum/OneDrive/Desktop/snoopytwo.gif"
        photo = tk.PhotoImage(file=image_path)
        image_label = tk.Label(recommendations_window, image=photo, bg="red")
        image_label.photo = photo  # To prevent the image from being garbage collected
        image_label.pack()

        # Restart button
        restart_button = tk.Button(recommendations_window, text="Restart", command=self.restart_quiz, bg="white", fg="green")
        restart_button.pack(side="left")

        # Exit button
        exit_button = tk.Button(recommendations_window, text="Exit", command=self.master.destroy, bg="white", fg="red")
        exit_button.pack(side="right")

        # Clear the user answers for the next quiz
        self.user_answers = []

    def restart_quiz(self):
        """
        Restart the quiz by closing the recommendations window and creating a new instance of the application.

        This method is called when the user clicks the "Restart" button.

        Returns:
        - None
        """
        # Close the recommendations window
        self.master.destroy()
        # Restart the entire program by creating a new instance of the application
        app = BookRecommendationsApp()
        app.run()


class WelcomeWindow(tk.Toplevel):
    def __init__(self, master, on_start):
        """
        Initialize the WelcomeWindow.

        This method sets up the WelcomeWindow, including a welcome message, an image, and a start button.

        Parameters:
        - master: The master Tkinter window.
        - on_start: The function to call when the user clicks the "Start" button.

        Returns:
        - None
        """
        super().__init__(master)
        self.title("Welcome")
        self.geometry("600x500")  # Adjusted height to accommodate the image
        self.configure(bg="#006400")

        label = tk.Label(self, text="Welcome to the Book Recommendation Quiz!", font=("Verdana", 18), fg="white", bg="#006400")
        label.pack(pady=10)

        # Load and display the GIF image
        image_path = "C:/Users/autum/OneDrive/Desktop/snoopy.gif"  # Replace with the actual path to your GIF image
        photo = tk.PhotoImage(file=image_path)
        image_label = tk.Label(self, image=photo, bg="#006400")
        image_label.photo = photo  # To prevent the image from being garbage collected
        image_label.pack(pady=10)

        start_button = tk.Button(self, text="Start", command=on_start, font=("Verdana", 18), fg="white", bg="#006400")
        start_button.pack(pady=10)


class BookRecommendationsApp:
    def __init__(self):
        """
        Initialize the BookRecommendationsApp.

        This method sets up the main application, including the root Tkinter window and the WelcomeWindow.

        Returns:
        - None
        """
        self.root = tk.Tk()
        self.root.title("Book Recommendation App")
        self.welcome_window = WelcomeWindow(self.root, self.show_question_window)

    def show_question_window(self):
        """
        Hide the main window and show the QuestionsWindow.

        This method is called when the user clicks the "Start" button in the WelcomeWindow.

        Returns:
        - None
        """
        self.root.withdraw()  # Hide the main window temporarily
        questions_data = [
            {
                "question": "Do you like long or short books?",
                "answers": ["Long", "Short"]
            },
            {
                "question": "Which genre do you like best?",
                "answers": ["Horror", "Romance", "Comedy", "Adventure/Fantasy", "Non-fiction"]
            },
            {
                "question": "Are you over 18? Be honest!",
                "answers": ["Yes", "No"]
            }
        ]

        # Create and display the QuestionsWindow
        self.questions_window = QuestionsWindow(self.root, questions_data, self.on_submit)

    def on_submit(self, user_answers):
        """
        Placeholder logic for handling user answers.

        This method is called when the user submits answers in the QuestionsWindow.

        Parameters:
        - user_answers: A list of user's answers.

        Returns:
        - None
        """
        print("User answers:", user_answers)
        print("Show recommendations window")

    def run(self):
        """
        Re-show the main window.

        This method is called to re-show the main window after the QuestionsWindow is closed.

        Returns:
        - None
        """
        self.root.deiconify()  # Re-show the main window
        self.root.mainloop()

if __name__ == "__main__":
    app = BookRecommendationsApp()
    app.run()
