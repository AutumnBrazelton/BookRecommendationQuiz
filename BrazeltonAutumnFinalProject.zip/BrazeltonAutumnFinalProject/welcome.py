import tkinter as tk

class WelcomeWindow:
    def __init__(self, master, on_start):
        """
        Initialize the WelcomeWindow.

        This method sets up the WelcomeWindow, including the welcome message, image, and start button.

        Parameters:
        - master: The master Tkinter window.
        - on_start: The function to call when the "Start" button is pressed.

        Returns:
        - None
        """
        self.master = master
        self.master.title("Welcome")
        self.master.geometry("950x700")  # Adjusted height to accommodate the image
        self.master.configure(bg="#006400")

        label = tk.Label(self.master, text="Welcome to the Book Recommendation Quiz! Simply press start and answer the following questions to be matched with three books.", font=("YourCoolFont", 12), fg="white", bg="#006400")
        label.pack(pady=10)

        # Load and display the GIF image
        image_path = "C:/Users/autum/OneDrive/Desktop/snoopy.gif"  # Replace with the actual path to your GIF image
        photo = tk.PhotoImage(file=image_path)
        image_label = tk.Label(self.master, image=photo, bg="#006400")
        image_label.photo = photo  # To prevent the image from being garbage collected
        image_label.pack(pady=10)

        start_button = tk.Button(self.master, text="Start", command=on_start, font=("Verdana", 18), fg="white", bg="#006400")
        start_button.pack(pady=10)

# Add any additional code specific to your application if needed
# For example, if there are other classes or functions, include them here
